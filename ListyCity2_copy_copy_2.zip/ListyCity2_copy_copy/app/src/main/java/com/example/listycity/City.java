package com.example.listycity;

/**
 * This is a class that defines a City.
 */
public class City implements Comparable {
    /** the city name */
    private String city;

    /** the city's province */
    private String province;

    /**
     * The constructor for a new city object with the given city name and province.
     *
     * @param city     the city name
     * @param province the city's province
     */
    City(String city, String province){
        this.city = city;
        this.province = province;
    }

    /**
     * Returns the city name.
     *
     * @return the city name
     */
    String getCityName(){
        return this.city;
    }

    /**
     * Returns the name of the city's province.
     *
     * @return the province name
     */
    String getProvinceName(){
        return this.province;
    }

    /**
     * Compares this city to another city alphabetically by name.
     *
     * @param o the City object to compare with
     * @return a negative integer, zero, or a positive integer
     */
    @Override
    public int compareTo(Object o) {
        City city = (City) o;
        return this.city.compareTo(city.getCityName()); // this.city refers to the city name
    }
}
